# Этот файл может быть пустым, или содержать только:
from app.routes import main, auth, dashboard